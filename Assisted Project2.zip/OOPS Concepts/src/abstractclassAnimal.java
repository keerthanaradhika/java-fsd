abstract class Animal{
   //abstract method
   public abstract void animalSound();
}
public class abstractclassAnimal extends Animal{

   public void animalSound(){
	System.out.println("Cat");
   }
   public static void main(String args[]){
	Animal obj = new abstractclassAnimal();
	obj.animalSound();
   }
}