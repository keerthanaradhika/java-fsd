public class object {
   //fields (or instance variable)
   String objName;
   int objAge;

   // constructor
   object(String name, int age){
      this.objName = name;
      this.objAge = age;
   }
   public static void main(String args[]){
      //Creating objects
      object obj1 = new object("Google", 5);
      object obj2 = new object("Yahoo", 2);

     //Accessing object data through reference
     System.out.println(obj1.objName+" "+obj1.objAge);
     System.out.println(obj2.objName+" "+obj2.objAge);
}
}