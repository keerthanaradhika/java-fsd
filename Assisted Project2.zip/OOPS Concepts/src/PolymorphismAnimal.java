class PolymorphismAnimal {
  public void animalSound() {
    System.out.println("The animal makes a sound");
  }
}

class Cow extends PolymorphismAnimal{
  public void animalSound() {
    System.out.println("The Cow says: maa maa");
  }
}

class Dog extends PolymorphismAnimal {
  public void animalSound() {
    System.out.println("The dog says: bow wow");
  }
}