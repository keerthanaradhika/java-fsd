import java.io.File;  
public class deletefile
{  
public static void main(String[] args)  
{     
try  
{         
File f= new File("E:\\demo.txt");           
if(f.delete())                      
{  
System.out.println(f.getName() + " deleted");      
}  
else  
{  
System.out.println("framework");  
}  
}  
catch(Exception e)  
{  
e.printStackTrace();  
}  
}  
}  