class MyThread extends Thread
{
 	public void run()
 	{
  		System.out.println("Exception");
 	}
}

class ThreadClass
{
 	public static void main(String args[])
 	{
  		MyThread mt = new  MyThread();
  		mt.start();
 	}
}
