
class Outer_Test {
   int num;
    
   // inner class
   private class Inner_Test {
      public void print() {
         System.out.println("InnerCircle");
      }
   }
    
   // Accessing he inner class from the method 
   void display_Inner() {
      Inner_Test inner = new Inner_Test();
      inner.print();
   }
}
    
public class innerclass {
 
   public static void main(String args[]) {
      // Instantiating the outer class 
      Outer_Test outer = new Outer_Test();
       
      // Accessing the display_Inner() method.
      outer.display_Inner();
   }
}