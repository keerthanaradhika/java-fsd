public class MethodsExample{
	public int addNumbers(int x, int y){
		int addition = x+y;
		return addition;
		}
	public static void main(String args[]) {
		int a = 28;
		int b = 42;
		MethodsExample obj = new MethodsExample();
		int result = obj.addNumbers(a,b);
		System.out.println("Sum of a+b = " + result);
	}
}