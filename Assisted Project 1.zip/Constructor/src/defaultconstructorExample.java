
 class Main {
    int num;
    String name;
 
    // this would be invoked while an object
    // of that class is created.
    Main() { System.out.println("Sunny"); }
}
 
class defaultconstructorExample {
    public static void main(String[] args)
    {
        // this would invoke default constructor.
        Main main2 = new Main();
 
        // Default constructor provides the default
        // values to the object like 0, null
        System.out.println(main2.name);
        System.out.println(main2.num);
    }
}