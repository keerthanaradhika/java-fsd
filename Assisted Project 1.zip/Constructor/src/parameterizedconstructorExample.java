
class Sample {
    // data members of the class.
    String name;
    int id;
 
    // Constructor would initialize data members
    // With the values of passed arguments while
    // Object of that class created
    Sample(String name, int id)
    {
        this.name = name;
        this.id = id;
    }
}
 
// Class 2
class parameterizedconstructorExample {
    // main driver method
    public static void main(String[] args)
    {
        // This would invoke the parameterized constructor.
        Sample example1 = new Sample("Rainy", 5);
        System.out.println("SampleName :" + example1.name
                           + " and SampleId :" + example1.id);
    }
}