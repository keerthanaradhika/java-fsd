import java.util.*;

public class queueInterface {

public static void main(String[] args) {

Queue<String> queue = new LinkedList<>();

queue.add("Orange");

queue.add("Mango");

queue.add("Grapes");

queue.add("Strawberry");

System.out.println(queue);

queue.remove("Grapes");

System.out.println(queue);

System.out.println("Queue total Size: " + queue.size());

System.out.println("Queue includes fruit 'Orange'? : " + queue.contains("Apple"));

queue.clear();

}

}