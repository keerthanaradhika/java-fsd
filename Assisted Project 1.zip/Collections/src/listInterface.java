import java.util.*;

public class listInterface {

public static void main(String args[]) {

List<String> list = new ArrayList<String>();

list.add("Gokul");

list.add("Karthi");

list.add("Vijay");

list.add("Anand");

list.add("Aadhitya");

for (String Students : list)

System.out.println(Students);

}

}