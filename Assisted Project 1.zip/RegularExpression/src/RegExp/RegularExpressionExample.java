package RegExp;
import java.util.ArrayList;
import java.util.regex.*;
public class RegularExpressionExample {
	public static void main(String args[]) {
		ArrayList<String> emails = new ArrayList<String>();
		emails.add("gkee.skee@gmail.com");
		emails.add("keerthu.sundar@gmail.com");
		String regex = "^(.+)@(.+)$";
		Pattern pattern = Pattern.compile(regex);
		for(String email : emails) {
			Matcher matcher = pattern.matcher(email);
			System.out.println(email +" : "+ matcher.matches()+"\n");
		}
	}

}
