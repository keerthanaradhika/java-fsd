package Public;

class G
{ 
   public void display() 
      { 
          System.out.println("Java FSD!!"); 
      } 
} 
class publicExample
{ 
    public static void main(String args[]) 
      { 
          G obj = new G (); 
          obj.display(); 
      } 
}