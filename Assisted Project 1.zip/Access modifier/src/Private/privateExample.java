package Private;

class DataClass {
    private String strname;    
 
// getter method
    public String getName() {
        return this.strname;
    }
    // setter method
    public void setName(String name) {
        this.strname= name;
    }
}
public class privateExample {
    public static void main(String[] main){
        DataClass d = new DataClass();       
 
 // access the private variable using the getter and setter
        d.setName("Welcome To All");
        System.out.println(d.getName());
    }
}